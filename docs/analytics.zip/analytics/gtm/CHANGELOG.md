# GTM container changelog — GTM-KC78NFHD

Record each production publish here. Export JSON to this folder after publishing (see [Roadmap §2.5](../GA4-GTM-ROADMAP-AND-REPORTING.md#25-version-control-gtm-container-exports)).

| Date | Version / export file | Author | Summary |
|---|---|---|---|
| 2026-05 | `GTM-KC78NFHD_v34.json` (external audit export) | — | Baseline audited in May 2026 GA4/GTM audit |

## How to add an entry

1. GTM → **Admin** → **Export container** → export workspace version
2. Save as `GTM-KC78NFHD_vNN.json` in this directory
3. Add a row above with date, filename, your name, and a one-line summary of tag/trigger/variable changes
